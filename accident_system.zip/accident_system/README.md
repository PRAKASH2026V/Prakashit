# Traffic Accident Pattern Analysis and Severity Prediction System

A Django web application built around the Kaggle **US Accidents** dataset
(https://www.kaggle.com/datasets/sobhanmoosavi/us-accidents), covering four modules:

1. **Accident Data Management** — upload the CSV (or any sampled subset — the full file is
   several GB / ~7.7M rows), parsed with Pandas and bulk-loaded into the database (SQLite by
   default, MySQL-ready); browse imported records with pagination.
2. **Accident Pattern Analysis** — severity distribution, accidents by hour split by severity,
   weather condition frequency, severity by day/night, and a correlation heatmap of weather
   variables against severity, plus plain-English findings. Charts via Matplotlib/Seaborn.
3. **Severity Prediction** — trains a `RandomForestClassifier` (scikit-learn) on temperature,
   humidity, visibility, wind speed, precipitation, hour of day, and road features (crossing,
   junction, traffic signal, day/night) to classify accident severity (1–4). Shows accuracy and
   macro F1, and lets you enter conditions to get a live prediction with class probabilities.
4. **Accident Dashboard** — summary counts by severity, accidents-by-hour chart, top states,
   and the active model's performance.

## Tech stack
Frontend: HTML, CSS, Bootstrap 5 · Backend: Python + Django · Data processing: Pandas, NumPy
Visualization: Matplotlib, Seaborn · ML: Scikit-learn · Database: SQLite (MySQL config included)

## Setup

```bash
python -m venv venv
source venv/bin/activate        # venv\Scripts\activate on Windows
pip install -r requirements.txt

python manage.py migrate
python manage.py createsuperuser   # optional, for /admin/
python manage.py runserver
```

Open http://127.0.0.1:8000/

## Getting the data

A small **synthetic** sample (`data/sample_us_accidents.csv`, 3000 rows) is included so the
app runs immediately — it exercises every module end to end.

For your actual submission, get the real dataset instead:
1. Go to https://www.kaggle.com/datasets/sobhanmoosavi/us-accidents
2. Download `US_Accidents_March23.csv` (it's large — several GB)
3. Recommended: take a manageable sample first, e.g. in a notebook:
   `pandas.read_csv("US_Accidents_March23.csv", nrows=200000).to_csv("us_accidents_sample.csv", index=False)`
4. In the running app, go to **Data Management** → upload the sampled file

The importer only reads the columns it needs (Start_Time, Severity, City, State, weather
fields, road-feature flags, Sunrise_Sunset) and auto-maps Kaggle's standard column names, so
the real file drops in with no code changes.

## Using it

1. **Data Management** → upload the CSV.
2. **Pattern Analysis** → view auto-generated charts and correlation findings.
3. **Severity Prediction** → click "Train / Retrain Model" (needs 50+ records), then fill in
   the form to get a predicted severity class with probabilities.
4. **Dashboard** → overview of everything at a glance.

## Switching to MySQL
In `accident_system/settings.py`, comment out the SQLite `DATABASES` entry and uncomment the
MySQL one, then `pip install mysqlclient` and create an `accident_db` database before running
`python manage.py migrate`.

## Project structure
```
accident_system/
├── manage.py
├── requirements.txt
├── data/
│   ├── generate_sample_data.py     # regenerates the synthetic sample CSV
│   └── sample_us_accidents.csv
├── accident_system/                # Django project (settings, urls)
└── accidentapp/                    # the app: models, views, forms, templates
    ├── models.py                   # AccidentRecord, DatasetUpload, TrainedModel
    ├── views.py                    # all 4 modules
    ├── ml/
    │   ├── train_model.py          # RandomForestClassifier training
    │   └── predict.py              # loads saved model, predicts + probabilities
    └── templates/accidentapp/
```
