"""
Generates a small synthetic CSV with the same key columns as Kaggle's
'US Accidents' dataset (https://www.kaggle.com/datasets/sobhanmoosavi/us-accidents)
so the app can be demoed before you download the real (multi-GB, ~7.7M row) file.

Run:  python generate_sample_data.py
Replace data/sample_us_accidents.csv with a real sample/subset of the Kaggle CSV
for the actual project submission (the importer only needs the columns below,
so you can even trim the full file down with pandas before uploading it).
"""
import numpy as np
import pandas as pd

np.random.seed(7)
n = 3000
start = pd.Timestamp("2020-01-01")
minutes_offset = np.random.randint(0, 60 * 24 * 365 * 3, n)
start_time = start + pd.to_timedelta(minutes_offset, unit="m")
hour = start_time.hour

cities = ["Los Angeles", "Houston", "Miami", "Chicago", "Atlanta", "Dallas", "Phoenix", "Charlotte"]
states = ["CA", "TX", "FL", "IL", "GA", "TX", "AZ", "NC"]
city_idx = np.random.randint(0, len(cities), n)

weather_conditions = ["Clear", "Cloudy", "Rain", "Fog", "Snow", "Overcast", "Light Rain", "Thunderstorm"]
weather = np.random.choice(weather_conditions, size=n, p=[0.35, 0.2, 0.12, 0.05, 0.03, 0.15, 0.07, 0.03])

is_night = ((hour < 6) | (hour > 19)).astype(int)
crossing = np.random.binomial(1, 0.15, n)
junction = np.random.binomial(1, 0.2, n)
stop = np.random.binomial(1, 0.05, n)
traffic_signal = np.random.binomial(1, 0.25, n)

bad_weather = np.isin(weather, ["Rain", "Fog", "Snow", "Thunderstorm"]).astype(int)
severity_base = 1 + bad_weather + is_night * 0.6 + junction * 0.3 + np.random.normal(0, 0.6, n)
severity = np.clip(np.round(severity_base), 1, 4).astype(int)

temperature_f = np.where(np.isin(weather, ["Snow"]), np.random.normal(28, 8, n), np.random.normal(68, 15, n))
humidity_pct = np.clip(np.random.normal(60, 20, n), 5, 100)
pressure_in = np.random.normal(29.9, 0.3, n)
visibility_mi = np.where(weather == "Fog", np.random.uniform(0.1, 3, n), np.random.uniform(6, 10, n))
wind_speed_mph = np.abs(np.random.normal(8, 5, n))
precipitation_in = np.where(np.isin(weather, ["Rain", "Thunderstorm", "Light Rain"]),
                             np.random.uniform(0.01, 0.8, n), 0.0)

df = pd.DataFrame({
    "Start_Time": start_time.strftime("%Y-%m-%d %H:%M:%S+00:00"),
    "Severity": severity,
    "City": [cities[i] for i in city_idx],
    "State": [states[i] for i in city_idx],
    "Temperature(F)": temperature_f.round(1),
    "Humidity(%)": humidity_pct.round(1),
    "Pressure(in)": pressure_in.round(2),
    "Visibility(mi)": visibility_mi.round(1),
    "Wind_Speed(mph)": wind_speed_mph.round(1),
    "Precipitation(in)": precipitation_in.round(2),
    "Weather_Condition": weather,
    "Crossing": crossing.astype(bool),
    "Junction": junction.astype(bool),
    "Stop": stop.astype(bool),
    "Traffic_Signal": traffic_signal.astype(bool),
    "Sunrise_Sunset": np.where(is_night, "Night", "Day"),
})

df.to_csv("sample_us_accidents.csv", index=False)
print(f"Wrote {len(df)} rows to sample_us_accidents.csv")
