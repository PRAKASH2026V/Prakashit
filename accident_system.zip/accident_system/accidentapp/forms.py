from django import forms
from .models import DatasetUpload


class DatasetUploadForm(forms.ModelForm):
    class Meta:
        model = DatasetUpload
        fields = ["file"]
        widgets = {
            "file": forms.ClearableFileInput(attrs={"class": "form-control", "accept": ".csv"})
        }


BOOL_CHOICES = [(0, "No"), (1, "Yes")]
DAY_NIGHT_CHOICES = [("Day", "Day"), ("Night", "Night")]


class SeverityPredictionForm(forms.Form):
    temperature_f = forms.FloatField(
        label="Temperature (°F)",
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.1", "placeholder": "e.g. 68"})
    )
    humidity_pct = forms.FloatField(
        label="Humidity (%)", min_value=0, max_value=100,
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.1", "placeholder": "e.g. 55"})
    )
    visibility_mi = forms.FloatField(
        label="Visibility (mi)", min_value=0,
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.1", "placeholder": "e.g. 10"})
    )
    wind_speed_mph = forms.FloatField(
        label="Wind Speed (mph)", min_value=0,
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.1", "placeholder": "e.g. 8"})
    )
    precipitation_in = forms.FloatField(
        label="Precipitation (in)", min_value=0, initial=0,
        widget=forms.NumberInput(attrs={"class": "form-control", "step": "0.01", "placeholder": "e.g. 0"})
    )
    hour = forms.IntegerField(
        label="Hour of Day (0-23)", min_value=0, max_value=23,
        widget=forms.NumberInput(attrs={"class": "form-control", "placeholder": "e.g. 17"})
    )
    crossing = forms.TypedChoiceField(label="Crossing nearby?", choices=BOOL_CHOICES, coerce=int,
                                       widget=forms.Select(attrs={"class": "form-select"}))
    junction = forms.TypedChoiceField(label="Junction nearby?", choices=BOOL_CHOICES, coerce=int,
                                       widget=forms.Select(attrs={"class": "form-select"}))
    traffic_signal = forms.TypedChoiceField(label="Traffic signal nearby?", choices=BOOL_CHOICES, coerce=int,
                                             widget=forms.Select(attrs={"class": "form-select"}))
    is_night = forms.TypedChoiceField(label="Day or Night", choices=[(0, "Day"), (1, "Night")], coerce=int,
                                       widget=forms.Select(attrs={"class": "form-select"}))
