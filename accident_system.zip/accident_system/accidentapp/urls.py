from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("data/", views.data_management, name="data_management"),
    path("analysis/", views.pattern_analysis, name="pattern_analysis"),
    path("predict/", views.severity_prediction, name="severity_prediction"),
]
