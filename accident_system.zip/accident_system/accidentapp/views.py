import base64
import io

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from django.contrib import messages
from django.core.paginator import Paginator
from django.shortcuts import render, redirect
from django.db.models import Count

from .models import AccidentRecord, DatasetUpload, TrainedModel
from .forms import DatasetUploadForm, SeverityPredictionForm
from .ml.predict import load_active_model, predict_severity
from .ml.train_model import train_and_save_model

sns.set_theme(style="darkgrid")


# ---------- helpers ----------

def fig_to_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight", dpi=110)
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")


def queryset_to_dataframe(qs):
    return pd.DataFrame.from_records(qs.values(
        "start_time", "severity", "city", "state", "temperature_f", "humidity_pct",
        "pressure_in", "visibility_mi", "wind_speed_mph", "precipitation_in",
        "weather_condition", "crossing", "junction", "stop", "traffic_signal", "sunrise_sunset",
    ))


# ---------- Module 4: Accident Dashboard ----------

def dashboard(request):
    total_records = AccidentRecord.objects.count()
    severity_counts = (
        AccidentRecord.objects.values("severity").annotate(count=Count("id")).order_by("severity")
    )
    top_states = (
        AccidentRecord.objects.values("state").annotate(count=Count("id")).order_by("-count")[:5]
    )
    active_model = TrainedModel.objects.filter(is_active=True).first()

    chart_b64 = None
    if total_records > 0:
        qs = AccidentRecord.objects.all()
        df = queryset_to_dataframe(qs)
        df["start_time"] = pd.to_datetime(df["start_time"])
        df["hour"] = df["start_time"].dt.hour
        by_hour = df.groupby("hour").size()

        fig, ax = plt.subplots(figsize=(8, 3.5))
        by_hour.plot(ax=ax, marker="o", color="#c0392b")
        ax.set_title("Accidents by Hour of Day")
        ax.set_xlabel("Hour")
        ax.set_ylabel("Accident Count")
        chart_b64 = fig_to_base64(fig)

    context = {
        "total_records": total_records,
        "severity_counts": severity_counts,
        "top_states": top_states,
        "active_model": active_model,
        "chart_b64": chart_b64,
    }
    return render(request, "accidentapp/dashboard.html", context)


# ---------- Module 1: Accident Data Management ----------

COLUMN_MAP = {
    "Start_Time": "start_time",
    "Severity": "severity",
    "City": "city",
    "State": "state",
    "Temperature(F)": "temperature_f",
    "Humidity(%)": "humidity_pct",
    "Pressure(in)": "pressure_in",
    "Visibility(mi)": "visibility_mi",
    "Wind_Speed(mph)": "wind_speed_mph",
    "Precipitation(in)": "precipitation_in",
    "Weather_Condition": "weather_condition",
    "Crossing": "crossing",
    "Junction": "junction",
    "Stop": "stop",
    "Traffic_Signal": "traffic_signal",
    "Sunrise_Sunset": "sunrise_sunset",
}


def data_management(request):
    if request.method == "POST":
        form = DatasetUploadForm(request.POST, request.FILES)
        if form.is_valid():
            upload = form.save()
            imported, skipped, error = import_csv(upload.file.path)
            upload.rows_imported = imported
            upload.rows_skipped = skipped
            upload.status = "failed" if error else "success"
            upload.notes = error or f"Imported {imported} rows, skipped {skipped}."
            upload.save()
            if error:
                messages.error(request, f"Import failed: {error}")
            else:
                messages.success(request, f"Imported {imported} rows ({skipped} skipped).")
            return redirect("data_management")
    else:
        form = DatasetUploadForm()

    uploads = DatasetUpload.objects.order_by("-uploaded_at")[:10]
    paginator = Paginator(AccidentRecord.objects.order_by("-start_time"), 25)
    page_obj = paginator.get_page(request.GET.get("page"))

    return render(request, "accidentapp/data_management.html", {
        "form": form,
        "uploads": uploads,
        "page_obj": page_obj,
        "total_records": AccidentRecord.objects.count(),
    })


def _to_bool(series):
    return series.astype(str).str.strip().str.lower().isin(["true", "1", "yes"])


def import_csv(file_path):
    """
    Parses a Kaggle 'US Accidents' style CSV (any subset/sample of the
    full ~7.7M row file works) and bulk-inserts rows.
    Returns (imported_count, skipped_count, error_message_or_None).
    """
    try:
        # US Accidents files can be huge; read only the columns we need.
        usecols = [c for c in COLUMN_MAP if True]  # placeholder, real filtering happens after peek
        preview = pd.read_csv(file_path, nrows=5)
        usecols = [c for c in COLUMN_MAP if c in preview.columns]
        df = pd.read_csv(file_path, usecols=usecols, low_memory=False)
    except Exception as exc:
        return 0, 0, f"Could not read CSV: {exc}"

    df = df.rename(columns=COLUMN_MAP)

    needed = ["start_time", "severity"]
    missing = [c for c in needed if c not in df.columns]
    if missing:
        return 0, 0, f"Missing required columns: {', '.join(missing)}"

    df["start_time"] = pd.to_datetime(df["start_time"], errors="coerce")
    before = len(df)
    df = df.dropna(subset=["start_time", "severity"])
    skipped = before - len(df)

    for boolcol in ["crossing", "junction", "stop", "traffic_signal"]:
        if boolcol in df.columns:
            df[boolcol] = _to_bool(df[boolcol])
        else:
            df[boolcol] = False

    for numcol in ["temperature_f", "humidity_pct", "pressure_in", "visibility_mi",
                   "wind_speed_mph", "precipitation_in"]:
        if numcol not in df.columns:
            df[numcol] = np.nan

    for strcol in ["city", "state", "weather_condition", "sunrise_sunset"]:
        if strcol not in df.columns:
            df[strcol] = ""
        df[strcol] = df[strcol].fillna("")

    records = [
        AccidentRecord(
            start_time=row["start_time"],
            severity=int(row["severity"]),
            city=str(row["city"])[:100],
            state=str(row["state"])[:10],
            temperature_f=row["temperature_f"] if pd.notna(row["temperature_f"]) else None,
            humidity_pct=row["humidity_pct"] if pd.notna(row["humidity_pct"]) else None,
            pressure_in=row["pressure_in"] if pd.notna(row["pressure_in"]) else None,
            visibility_mi=row["visibility_mi"] if pd.notna(row["visibility_mi"]) else None,
            wind_speed_mph=row["wind_speed_mph"] if pd.notna(row["wind_speed_mph"]) else None,
            precipitation_in=row["precipitation_in"] if pd.notna(row["precipitation_in"]) else None,
            weather_condition=str(row["weather_condition"])[:100],
            crossing=bool(row["crossing"]),
            junction=bool(row["junction"]),
            stop=bool(row["stop"]),
            traffic_signal=bool(row["traffic_signal"]),
            sunrise_sunset=str(row["sunrise_sunset"])[:10],
        )
        for _, row in df.iterrows()
    ]
    AccidentRecord.objects.bulk_create(records, batch_size=1000, ignore_conflicts=True)
    return len(records), skipped, None


# ---------- Module 2: Accident Pattern Analysis ----------

def pattern_analysis(request):
    qs = AccidentRecord.objects.all()
    if not qs.exists():
        return render(request, "accidentapp/pattern_analysis.html", {"has_data": False})

    df = queryset_to_dataframe(qs)
    df["start_time"] = pd.to_datetime(df["start_time"])
    df["hour"] = df["start_time"].dt.hour
    df["day_of_week"] = df["start_time"].dt.day_name()

    charts = {}

    # 1. Severity distribution
    fig, ax = plt.subplots(figsize=(6, 4))
    df["severity"].value_counts().sort_index().plot(kind="bar", ax=ax, color="#c0392b")
    ax.set_title("Accident Severity Distribution")
    ax.set_xlabel("Severity (1=least, 4=most)")
    ax.set_ylabel("Count")
    charts["severity_dist"] = fig_to_base64(fig)

    # 2. Accidents by hour, split by severity
    fig, ax = plt.subplots(figsize=(7, 4))
    hourly_sev = df.groupby(["hour", "severity"]).size().unstack(fill_value=0)
    hourly_sev.plot(ax=ax, colormap="autumn")
    ax.set_title("Accidents by Hour, by Severity")
    ax.set_xlabel("Hour of Day")
    charts["hourly_severity"] = fig_to_base64(fig)

    # 3. Weather condition frequency
    top_weather = df["weather_condition"].replace("", np.nan).dropna().value_counts().head(8)
    fig, ax = plt.subplots(figsize=(7, 4))
    top_weather.plot(kind="barh", ax=ax, color="#2f6690")
    ax.set_title("Most Common Weather Conditions at Accident Sites")
    ax.invert_yaxis()
    charts["weather_freq"] = fig_to_base64(fig)

    # 4. Severity by day/night
    fig, ax = plt.subplots(figsize=(6, 4))
    daynight = df[df["sunrise_sunset"].isin(["Day", "Night"])]
    if len(daynight):
        sns.countplot(data=daynight, x="severity", hue="sunrise_sunset", ax=ax, palette="Set2")
        ax.set_title("Severity by Day / Night")
    charts["daynight"] = fig_to_base64(fig)

    # 5. Correlation heatmap of numeric weather variables with severity
    numeric_cols = ["severity", "temperature_f", "humidity_pct", "pressure_in",
                     "visibility_mi", "wind_speed_mph", "precipitation_in"]
    corr = df[numeric_cols].corr()
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", ax=ax, vmin=-1, vmax=1)
    ax.set_title("Correlation With Severity")
    charts["correlation"] = fig_to_base64(fig)

    insights = build_insights(corr, df)

    return render(request, "accidentapp/pattern_analysis.html", {
        "has_data": True,
        "charts": charts,
        "insights": insights,
        "record_count": len(df),
    })


def build_insights(corr, df):
    insights = []
    for col, label in [
        ("visibility_mi", "Visibility"), ("precipitation_in", "Precipitation"),
        ("wind_speed_mph", "Wind speed"), ("humidity_pct", "Humidity"),
        ("temperature_f", "Temperature"),
    ]:
        if col in corr.columns:
            val = corr.loc["severity", col]
            strength = "strong" if abs(val) > 0.3 else "moderate" if abs(val) > 0.15 else "weak"
            direction = "positive" if val > 0 else "negative"
            insights.append(f"{label} vs severity: {strength} {direction} correlation (r = {val:.2f})")

    if len(df):
        night_share = (df["sunrise_sunset"] == "Night").mean()
        insights.append(f"{night_share:.0%} of recorded accidents occurred at night.")
        signal_severity = df.groupby("traffic_signal")["severity"].mean()
        if True in signal_severity.index and False in signal_severity.index:
            insights.append(
                f"Avg severity near a traffic signal: {signal_severity.get(True, 0):.2f} "
                f"vs {signal_severity.get(False, 0):.2f} without one."
            )
    return insights


# ---------- Module 3: Severity Prediction ----------

def severity_prediction(request):
    active_model = TrainedModel.objects.filter(is_active=True).first()
    prediction_result = None
    form = SeverityPredictionForm()

    if request.method == "POST":
        if "train_model" in request.POST:
            count = AccidentRecord.objects.count()
            if count < 50:
                messages.error(request, "Need at least 50 accident records before training. Import data first.")
            else:
                qs = AccidentRecord.objects.all()
                df = queryset_to_dataframe(qs)
                metrics = train_and_save_model(df)
                messages.success(
                    request,
                    f"Model trained: {metrics['algorithm']} | "
                    f"Accuracy = {metrics['accuracy']:.2%} | Macro F1 = {metrics['f1_macro']:.3f}"
                )
            return redirect("severity_prediction")

        form = SeverityPredictionForm(request.POST)
        if form.is_valid() and active_model:
            model, feature_names = load_active_model()
            prediction_result = predict_severity(model, feature_names, form.cleaned_data)
        elif not active_model:
            messages.warning(request, "Train a model first before making predictions.")

    history = TrainedModel.objects.order_by("-trained_at")[:10]

    return render(request, "accidentapp/severity_prediction.html", {
        "form": form,
        "active_model": active_model,
        "history": history,
        "prediction_result": prediction_result,
        "record_count": AccidentRecord.objects.count(),
    })
