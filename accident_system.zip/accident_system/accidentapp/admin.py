from django.contrib import admin
from .models import AccidentRecord, DatasetUpload, TrainedModel


@admin.register(AccidentRecord)
class AccidentRecordAdmin(admin.ModelAdmin):
    list_display = ("start_time", "severity", "city", "state", "weather_condition")
    list_filter = ("severity", "state", "sunrise_sunset")
    date_hierarchy = "start_time"


@admin.register(DatasetUpload)
class DatasetUploadAdmin(admin.ModelAdmin):
    list_display = ("id", "uploaded_at", "status", "rows_imported", "rows_skipped")


@admin.register(TrainedModel)
class TrainedModelAdmin(admin.ModelAdmin):
    list_display = ("id", "algorithm", "trained_at", "accuracy", "f1_macro", "is_active")
