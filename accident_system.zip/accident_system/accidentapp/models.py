from django.db import models


class AccidentRecord(models.Model):
    """
    One row of the Kaggle 'US Accidents' dataset (trimmed to the columns
    this project uses). https://www.kaggle.com/datasets/sobhanmoosavi/us-accidents
    """
    start_time = models.DateTimeField(db_index=True)
    severity = models.PositiveSmallIntegerField(help_text="1 (least) to 4 (most) impact on traffic")
    city = models.CharField(max_length=100, blank=True)
    state = models.CharField(max_length=10, blank=True)
    temperature_f = models.FloatField(null=True, blank=True)
    humidity_pct = models.FloatField(null=True, blank=True)
    pressure_in = models.FloatField(null=True, blank=True)
    visibility_mi = models.FloatField(null=True, blank=True)
    wind_speed_mph = models.FloatField(null=True, blank=True)
    precipitation_in = models.FloatField(null=True, blank=True)
    weather_condition = models.CharField(max_length=100, blank=True)
    # Road-feature flags present at the accident site
    crossing = models.BooleanField(default=False)
    junction = models.BooleanField(default=False)
    stop = models.BooleanField(default=False)
    traffic_signal = models.BooleanField(default=False)
    sunrise_sunset = models.CharField(max_length=10, blank=True, help_text="Day / Night")

    class Meta:
        ordering = ["start_time"]
        indexes = [models.Index(fields=["start_time"]), models.Index(fields=["severity"])]

    def __str__(self):
        return f"{self.start_time:%Y-%m-%d %H:%M} | Severity {self.severity} | {self.city}, {self.state}"


class DatasetUpload(models.Model):
    """Tracks each CSV import so Module 1 (Data Management) has an audit trail."""
    file = models.FileField(upload_to="uploads/")
    uploaded_at = models.DateTimeField(auto_now_add=True)
    rows_imported = models.PositiveIntegerField(default=0)
    rows_skipped = models.PositiveIntegerField(default=0)
    status = models.CharField(max_length=20, default="pending")  # pending/success/failed
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"Upload #{self.pk} ({self.status})"


class TrainedModel(models.Model):
    """Metadata for each trained severity-classification model (Module 3)."""
    algorithm = models.CharField(max_length=50)
    trained_at = models.DateTimeField(auto_now_add=True)
    features_used = models.TextField(help_text="Comma-separated feature list")
    accuracy = models.FloatField(null=True, blank=True)
    f1_macro = models.FloatField(null=True, blank=True)
    model_file = models.CharField(max_length=255, help_text="Path to the saved .joblib file")
    is_active = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.algorithm} (acc={self.accuracy})"
