"""
Trains a RandomForestClassifier to predict accident `severity` (1-4) from
weather and road-feature variables, evaluates it, and saves it with joblib.
Called from the "Train Model" button on the Severity Prediction page.
"""
import os
import joblib
import numpy as np
import pandas as pd
from django.conf import settings
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score

FEATURE_COLUMNS = [
    "temperature_f",
    "humidity_pct",
    "visibility_mi",
    "wind_speed_mph",
    "precipitation_in",
    "hour",
    "crossing",
    "junction",
    "traffic_signal",
    "is_night",
]
TARGET_COLUMN = "severity"


def _prepare_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["start_time"] = pd.to_datetime(df["start_time"])
    df["hour"] = df["start_time"].dt.hour
    df["is_night"] = (df["sunrise_sunset"] == "Night").astype(int)
    df["crossing"] = df["crossing"].astype(int)
    df["junction"] = df["junction"].astype(int)
    df["traffic_signal"] = df["traffic_signal"].astype(int)

    for col in ["temperature_f", "humidity_pct", "visibility_mi", "wind_speed_mph", "precipitation_in"]:
        df[col] = df[col].fillna(df[col].median())

    df = df.dropna(subset=FEATURE_COLUMNS + [TARGET_COLUMN])
    return df


def train_and_save_model(df: pd.DataFrame) -> dict:
    from ..models import TrainedModel

    df = _prepare_features(df)
    X = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMN]

    stratify = y if y.value_counts().min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=stratify
    )

    model = RandomForestClassifier(
        n_estimators=200, max_depth=14, random_state=42, n_jobs=-1, class_weight="balanced"
    )
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    f1 = f1_score(y_test, preds, average="macro")

    os.makedirs(settings.ML_MODEL_DIR, exist_ok=True)
    path = os.path.join(settings.ML_MODEL_DIR, "rf_severity_model.joblib")
    joblib.dump({"model": model, "features": FEATURE_COLUMNS}, path)

    TrainedModel.objects.update(is_active=False)
    TrainedModel.objects.create(
        algorithm="RandomForestClassifier",
        features_used=", ".join(FEATURE_COLUMNS),
        accuracy=acc,
        f1_macro=f1,
        model_file=path,
        is_active=True,
    )

    return {"algorithm": "Random Forest Classifier", "accuracy": acc, "f1_macro": f1}
