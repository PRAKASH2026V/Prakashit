import joblib
import pandas as pd


def load_active_model():
    from ..models import TrainedModel
    active = TrainedModel.objects.filter(is_active=True).first()
    if not active:
        return None, None
    saved = joblib.load(active.model_file)
    return saved["model"], saved["features"]


def predict_severity(model, feature_names, cleaned_form_data: dict) -> dict:
    row = {name: cleaned_form_data[name] for name in feature_names}
    X = pd.DataFrame([row])
    predicted = int(model.predict(X)[0])
    proba = None
    if hasattr(model, "predict_proba"):
        classes = list(model.classes_)
        probs = model.predict_proba(X)[0]
        proba = {int(c): round(float(p) * 100, 1) for c, p in zip(classes, probs)}
    return {"predicted_severity": predicted, "probabilities": proba, "inputs": row}
